from ._version import __version__
from .weakrefmethod import WeakMethod
